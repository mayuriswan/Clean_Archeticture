﻿namespace Web;

public static class AssemblyReference
{
}