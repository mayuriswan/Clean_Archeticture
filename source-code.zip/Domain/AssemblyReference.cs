﻿namespace Domain;

public static class AssemblyReference
{
}