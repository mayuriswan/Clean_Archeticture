﻿namespace Infrastructure;

public static class AssemblyReference
{
}